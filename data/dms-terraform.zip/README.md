## terraform commands
- $ terraform init -var-file "environments/dev/variables.tfvars"
- $ terraform plan -var-file "environments/dev/variables.tfvars" -out tfplan
- $ terraform apply "tfplan"

## prerequisites
- security groupid
- vpc name (tag name)
